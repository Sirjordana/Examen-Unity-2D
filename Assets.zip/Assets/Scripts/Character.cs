using Unity.VisualScripting;
using UnityEngine;

public class Character : MonoBehaviour
{
    public float health = 100f;
    public float speed = 5f;

    public float protection = 100f;

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            TakeDamage(7);
        }
    }

    // Method for moving the character
    public virtual void Move(Vector2 direction)
    {
        transform.Translate(direction * speed * Time.deltaTime);
    }

    // Method for the character to receive damage
    public virtual void TakeDamage(float amount)
    {
        if (protection > 0)
        {
            if (amount > protection)
            {
                amount -= protection;
                protection = 0;
                TakeDamage(amount);
            }
            else
            {
                protection -= amount;
            }
        }
        else
        {
            health -= amount;
            if (health <= 0)
            {
                Die();
            }
        }
    }

    // Method to handle character's death
    protected void Die()
    {
        Debug.Log("Character has died.");
        Destroy(gameObject);
    }
}