using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private Animator anim;

    private float HorizontalInput;

    [Header("Controls")]
    public KeyCode Attack = KeyCode.Alpha1;
    public KeyCode Hurt = KeyCode.Alpha2;
    public KeyCode Die = KeyCode.Alpha3;
    
    [Header("Teleport")]
    public float teleport_x;
    public float teleport_y;

    private void Awake()
    {
        anim = GetComponent<Animator>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        HorizontalInput = Input.GetAxis("Horizontal");

        if (HorizontalInput > 0)
        {
            transform.localScale = Vector3.one;
        }
        else if (HorizontalInput < 0)
        {
            transform.localScale = new Vector3(-1, 1, 1);
        }

        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            anim.SetTrigger("Attack");
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            anim.SetTrigger("Hurt");
        }

        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            anim.SetTrigger("Die");
        }
    }

    public void Teleport()
    {
        if (transform.localScale.x > 0)
        {
            transform.position = new Vector3(transform.position.x + teleport_x, transform.position.y + teleport_y, transform.position.z);
        }
        else if (transform.localScale.x < 0)
        {
            transform.position = new Vector3(transform.position.x - teleport_x, transform.position.y + teleport_y, transform.position.z);
        }
        
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;

        Gizmos.DrawLine(transform.position, new Vector3(transform.position.x + teleport_x, transform.position.y + teleport_y, transform.position.z));
    }
}
